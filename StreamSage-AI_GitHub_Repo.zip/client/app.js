function startEditing() {
  document.getElementById("output").innerText = "🔥 Editing your stream... detecting funny moments, adding memes & SFX...";
}

function generateThumbnail() {
  document.getElementById("output").innerText = "🖼️ Generating AI thumbnail with your face... pulling streamer styles...";
}
