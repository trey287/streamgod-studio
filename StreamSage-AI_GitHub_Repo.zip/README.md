# StreamSage AI

An AI-powered streamer editor with meme detection and face-based thumbnail generator.